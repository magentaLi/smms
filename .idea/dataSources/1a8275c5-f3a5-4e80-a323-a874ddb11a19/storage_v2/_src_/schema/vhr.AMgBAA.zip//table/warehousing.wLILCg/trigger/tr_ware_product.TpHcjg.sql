create trigger tr_ware_product
  after INSERT
  on warehousing
  for each row
BEGIN
    UPDATE product SET kucun = (kucun+new.productCount) WHERE product.productCode = new.productCode;
END;

