create trigger tr_return_product
  after INSERT
  on returnGoods
  for each row
BEGIN
    UPDATE product SET kucun = (kucun+new.returnCount) WHERE product.productCode = new.productCode;
END;

