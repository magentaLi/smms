create trigger tr_delivery_product
  after INSERT
  on delivery
  for each row
BEGIN
    UPDATE product SET kucun = (kucun-new.productCount) WHERE product.productCode = new.productCode;
END;

