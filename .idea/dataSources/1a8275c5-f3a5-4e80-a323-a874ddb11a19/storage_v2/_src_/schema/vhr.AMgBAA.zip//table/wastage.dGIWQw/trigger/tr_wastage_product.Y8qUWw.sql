create trigger tr_wastage_product
  after INSERT
  on wastage
  for each row
BEGIN
   IF new.addOrSub = 0 THEN

      UPDATE product SET kucun = (kucun-new.num) WHERE product.productCode = new.productCode;
   ELSE

      UPDATE product SET kucun = (kucun+new.num) WHERE product.productCode = new.productCode;
   END IF;
END;

